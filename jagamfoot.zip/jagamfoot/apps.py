from django.apps import AppConfig


class JagamfootConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jagamfoot'
